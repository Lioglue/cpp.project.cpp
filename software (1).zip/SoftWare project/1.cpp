#include<iostream>
#include<fstream>
#include <limits>

using namespace std;
int id;
string name;
string choice, add, more;
string E = "Error in reading the file";
string Name_tag = "Name: ";
string space_tag = " ";
string id_tag = "Id: ";

void code()
{
	ifstream file1("1.txt");
	ifstream file2("2.txt");
	ifstream file3("3.txt");
	ifstream file4("4.txt");
	ifstream file5("5.txt");
	string line;
	
	
	
while (true)
{	
	cout<<"Name: ";
	cin>>name;
	
	cout<<"Id: ";
	cin>>id;
	
	if (name == "akeab" && id == 1)
	{
		if (file1.is_open())
		{
			while(getline(file1, line))
			{
				cout<<line<<endl;
				
			}
		}
		else 
		{cout<<E;}
		
		file1.close();
		break;
	}
	
	
	else if (name == "sofonias" && id == 2)
	{
		if (file2.is_open())
		{
			while (getline(file2, line))
			{
				cout<<line<<endl;
			}
		
		}
		
		else{cout<<E;}
		
		file2.close();
		break;
	}
	
	else if (name == "christian" && id == 3)
	{
		if (file3.is_open())
		{
			while (getline(file3, line))
			{
				cout<<line<<endl;
			}
		}
		else 
		{cout<<E;}
		file3.close();
		break;
	}
	
	else if (name == "yonatan" && id == 4)
	{
		if (file4.is_open())
		{
			while (getline(file4, line))
			{
				cout<<line<<endl;
			}
		}
		else 
		{cout<<E;}
		file4.close();
		break;
	}
	
	

	else 
	{
	
	cout<<"There isn't Student with that kind of info please Enter try again :)"<<endl;
	
	cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
	while(true)
	{
	
	cout<<"do you want to add a new student to the system yes/no"<<endl;
	cin>>add;
	
	
	if (add == "yes")
	{
	string new_student_first_name, new_studnet_last_name;
	int new_student_id;
	ofstream file6("6.txt");
	
	cout<<"Please fill what the questions below"<<endl;
	cout<<"First Name: ";
	cin>>new_student_first_name;
	cout<<"New_Student_Last_ Name: ";
	cin>>new_studnet_last_name;
	cout<<"Id: ";
	cin>>new_student_id;
		if (file6.is_open())
		{
		file6<<Name_tag<<new_student_first_name;
		file6<<space_tag;
		file6<<new_studnet_last_name<<endl;
		file6<<id_tag<<new_student_id;
		}
	
	
		else 
		cout<<E;
	
	file6.clear();
	
	
	}
	
	else 
	break;
	
	
	
	
	cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
	}
	
	
	
	cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}
}
}



int main()
{
	cout<<"-----welcome to our School mannagment system----"<<endl;
	cout<<"-------please Enter the Studetn name and id-----"<<endl;
	code();
	while (true)
	{
	cout<<"Do you want to use it again yes/no"<<endl;
	cin>>choice;
		if (choice == "yes")
		{
			code();
			continue;
		}
		
		else if (choice == "no")
		{
			break;
		}
		
		else if (choice != "yes" || "no")
		{
			cout<<"Please enter yes or no only"<<endl;
			continue;
		}
	}
	
	

		
	

	return 0;
}
